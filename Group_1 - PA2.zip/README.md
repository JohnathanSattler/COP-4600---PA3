COP 4600 - PA2
======

This module will allow the user to input multiple characters at a time, but will allow for only 1 character to be read out at a time. 

###

Module:
------

Build Module: `make`

Install Module: `sudo insmod pa2.ko`

Remove Module: `sudo rmmod pa2`

View Kernal Messages: `dmesg`

###

Testing:
------

Compile: `gcc -o test test.c`

Run: `sudo ./test`
