COP 4600 - PA2
======

This module will allow the user to input multiple characters into a buffer at a time, and will allow the user to read the whole buffer when needed. 

###

Module:
------

Build Module: `make`

Install Module: `sudo insmod pa2.ko`

Remove Module: `sudo rmmod pa2`

View Kernal Messages: `dmesg`

###

Testing:
------

Compile: `gcc -o test test.c`

Run: `sudo ./test`
